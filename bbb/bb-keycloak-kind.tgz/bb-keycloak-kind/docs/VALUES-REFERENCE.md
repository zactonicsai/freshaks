# Big Bang Keycloak chart — values reference and schema notes

The Big Bang chart (`chart/`, 7.3.x-bb.x) validates every `helm install/upgrade/template` against
`chart/values.schema.json`. Unknown **top-level** keys are rejected outright
(`additional properties 'x' not allowed`), which is the error you get when you paste values written
for chart ≤ 24.x-bb.x or for the Big Bang umbrella. Below: what the top level accepts, what each
block means, and how the nested charts interpret their keys.

Inspect the real schema and defaults of the version you deploy — they change between releases:

```bash
CHART=.work/keycloak/chart                         # cloned by deploy.sh
jq -r '.properties | keys[]' $CHART/values.schema.json              # allowed top-level keys
jq '.properties.upstream.properties | keys' $CHART/values.schema.json 2>/dev/null   # if upstream is typed
jq '.additionalProperties' $CHART/values.schema.json                 # false = strict top level
helm show values $CHART > /tmp/defaults.yaml                         # effective defaults (incl. subcharts)
helm show values $CHART/charts/keycloakx > /tmp/keycloakx-defaults.yaml
helm template t $CHART -f values.yaml | less                         # what you'd actually deploy
```

---

## 1. Top level (Big Bang wrapper)

| Key | Type | What it is |
|---|---|---|
| `global.domain` | string | Cluster DNS domain used by Big Bang templating (`keycloak.{{ .Values.global.domain }}`). Default `dev.bigbang.mil` |
| `global.imagePullSecrets` | list | Pull secrets passed down to subcharts that honour `global.*` (the Bitnami Postgres chart does; keycloakx does **not** — use `upstream.imagePullSecrets`) |
| `bb-common` | object | The Big Bang library subchart: Istio routes, NetworkPolicies, AuthorizationPolicies, ServiceEntries. §2 |
| `upstream` | object | **All Keycloak settings** — passed verbatim to the codecentric `keycloakx` subchart. §3 |
| `postgresql` | object | Bundled Bitnami PostgreSQL subchart. §4 |
| `bbtests` | object | Big Bang CI test hooks (Cypress + scripts). `enabled: false` outside Big Bang pipelines |
| `nameOverride` / `fullnameOverride` | string | Usually absent/locked; the chart pins the fullname to `keycloak-keycloak`, which is why resources are `keycloak-keycloak`, `keycloak-keycloak-http`, `keycloak-keycloak-env` |

Keys that are **gone** (schema error if present): `domain`, `istio`, `networkPolicies`, `hostname`,
`image`, `replicas`, `secrets`, `extraEnv` … everything Keycloak-related moved under `upstream:`, and
everything Istio/NetworkPolicy-related under `bb-common:`.

---

## 2. `bb-common` (Istio + network policy)

```yaml
bb-common:
  istio:
    enabled: false                 # master switch for Istio resources (VS, PeerAuth, AuthzPolicy, ServiceEntry)
    hardened:
      enabled: false               # Big Bang "hardened" mode: REGISTRY_ONLY egress + explicit ServiceEntries
    sidecar:
      enabled: true                # inject sidecar into the keycloak pods (namespace label is still needed)
      outboundTrafficPolicyMode: REGISTRY_ONLY   # or ALLOW_ANY
    mtls:
      mode: STRICT                 # PeerAuthentication for the workload
    serviceEntries:
      custom: []                   # extra ServiceEntry specs (external LDAP, SMTP, OIDC IdPs)
    authorizationPolicies:
      enabled: true
      generateFromNetpol: true     # derive allow-rules from the NetworkPolicies below
      custom: []
  networkPolicies:
    enabled: false
    ingress: {}                    # named ingress definitions (who may reach keycloak)
    egress:
      definitions:                 # named CIDR/port sets, e.g. smtp-subnets, ldap-subnets
        ldap-subnets:
          to: [{ipBlock: {cidr: 10.0.0.0/8}}]
          ports: [{port: 636, protocol: TCP}]
      from:
        keycloak:
          to:
            k8s: ["tempo/tempo:9411"]          # <namespace>/<service>:<port>
            definition: ["ldap-subnets", "smtp-subnets"]
  routes:
    defaults:
      inbound:
        gateways: ["istio-gateway/public-ingressgateway"]
    inbound:
      keycloak:
        enabled: true
        gateways: ["istio-gateway/public-ingressgateway"]   # <ns>/<Gateway name>
        hosts: ["keycloak.{{ .Values.global.domain }}"]     # templated; use FQDNs
        service: keycloak-keycloak-http                      # target Service (templated)
        port: 80
        containerPort: 8080          # optional, for the NetworkPolicy when it differs from port
        passthrough:
          enabled: false             # true = SNI (tls) route; keep service keycloak-keycloak-http but port: 8443 (same Service carries both ports)
          gatewayPort: 8443
        serviceEntry: {enabled: true}
        selector: {app.kubernetes.io/name: keycloakx}        # pods the NetPol/AuthzPolicy apply to
        metadata: {labels: {}, annotations: {}}
```

Each enabled route renders: VirtualService (+ `tls:` match when passthrough), ServiceEntry,
NetworkPolicy (gateway ns → selector pods on `containerPort`), AuthorizationPolicy. They render only if
the `networking.istio.io/v1` API exists in the cluster.

---

## 3. `upstream` (codecentric keycloakx 7.x — every key, grouped)

**Typed values vs. template strings.** Many keycloakx fields accept *either* native YAML *or* a
string that is run through Helm `tpl` (so it may contain `{{ include "keycloak.fullname" . }}`).
In this chart version: `extraEnv`, `extraEnvFrom`, `extraVolumes`, `extraVolumeMounts`,
`extraInitContainers`, `extraContainers`, `affinity`, `lifecycleHooks`, `livenessProbe`,
`readinessProbe`, `startupProbe`, `volumeClaimTemplates`, `topologySpreadConstraints` and every
`secrets.<name>.stringData` value. Big Bang's defaults use the string form (`|-`), so when you
override one of them you replace the **whole** string — there is no merge. Native YAML and string
forms can't be mixed for the same key between files (`helm` would try to merge a map into a string
and fail).

### 3.1 Identity, image, scheduling

| Key | Default | Notes |
|---|---|---|
| `replicas` | 1 | ignored when `autoscaling.enabled` |
| `image.repository` / `image.tag` / `image.digest` / `image.pullPolicy` | quay.io image, chart appVersion | BB default is `registry1.dso.mil/ironbank/opensource/keycloak/keycloak`. Pin the tag |
| `imagePullSecrets` | `[]` | `[{name: private-registry}]` for Iron Bank |
| `command` / `args` | `["/opt/keycloak/bin/kc.sh"]` / `["start"]` | add `--import-realm`, `--optimized`, `--verbose`. `start-dev` only for throwaway dev |
| `podManagementPolicy` | `OrderedReady` | `Parallel` speeds scale-up; fine with jdbc-ping |
| `updateStrategy` | `RollingUpdate` | `OnDelete` if you want to drive upgrades pod-by-pod yourself |
| `affinity` (tpl) | anti-affinity on hostname (required) + zone (preferred) | keep for HA; override to `""` on single-node kind if pods stay Pending |
| `topologySpreadConstraints` (tpl) / `nodeSelector` / `tolerations` / `priorityClassName` | — | standard |
| `podDisruptionBudget` | `{}` | `{minAvailable: 1}` for HA |
| `terminationGracePeriodSeconds` | 60 | Keycloak drains sessions; raise if you use long requests |
| `podLabels` / `podAnnotations` / `statefulsetLabels` / `statefulsetAnnotations` / `commonLabels` | — | BB sets `traffic.sidecar.istio.io/excludeInboundPorts: "9000"` and `proxy.istio.io/config` here |
| `podSecurityContext` / `securityContext` | uid/gid 1000/0 upstream; **2000** in BB | match the image: quay.io = 1000:0, Iron Bank = 2000 |
| `serviceAccount.{create,name,annotations,labels,imagePullSecrets,automountServiceAccountToken}` | create | IRSA/Workload Identity annotations go here |
| `rbac.create` / `rbac.rules` | false | needed only for `KC_CACHE_STACK=kubernetes` (DNS/KUBE_PING) |
| `hostAliases` / `enableServiceLinks` / `clusterDomain` / `revisionHistoryLimit` / `restartPolicy` | — | rarely |

### 3.2 Runtime configuration (how KC_* reach the container)

| Key | Renders | Notes |
|---|---|---|
| `proxy.enabled` + `proxy.mode` | `KC_PROXY_HEADERS=<mode>` | `xforwarded` (Istio/NGINX) or `forwarded`. Replaces removed `--proxy` |
| `proxy.http.enabled` | `KC_HTTP_ENABLED=true` | needed unless you pass TLS through to the pod |
| `http.relativePath` | `KC_HTTP_RELATIVE_PATH` | upstream default `/auth` (legacy), BB/this repo `/` |
| `http.managementRelativePath` | `KC_HTTP_MANAGEMENT_RELATIVE_PATH` | `/` → probes at `/health/*`; empty inherits relativePath |
| `http.internalPort` / `http.internalScheme` | probe port name / scheme | `http-internal` = 9000; `HTTPS` when `KC_HTTPS_*` is set and management inherits TLS |
| `health.enabled` / `metrics.enabled` | `KC_HEALTH_ENABLED` / `KC_METRICS_ENABLED` | both required for the DB readiness check |
| `cache.stack` | `default` → `KC_CACHE=ispn`, `KC_CACHE_STACK=jdbc-ping` | `custom` = you set `KC_CACHE*` yourself (e.g. `kubernetes`, `local`) |
| `database.{vendor,hostname,port,database,username,password}` | `KC_DB`, `KC_DB_URL_HOST/PORT/DATABASE`, `KC_DB_USERNAME`, password Secret | `hostname` must be a resolvable Service/FQDN; bundled chart = `<release>-postgresql` |
| `database.existingSecret` / `existingSecretKey` | `KC_DB_PASSWORD` from your Secret | preferred in cloud; chart then creates no DB secret |
| `dbchecker.{enabled,image,securityContext,resources}` | init container `nc -z host port` | enable; avoids the first-boot connection race |
| `extraEnv` (tpl) | extra `env:` entries | **never** repeat vars the chart renders (`KC_HTTP_ENABLED`, `KC_PROXY_HEADERS`, `KC_CACHE*`, `KC_METRICS_ENABLED`, `KC_HEALTH_ENABLED`, `KC_DB*`, `KC_HTTP_RELATIVE_PATH`) — duplicate keys fail server-side apply |
| `extraEnvFrom` (tpl) | `envFrom:` | BB default: `- secretRef: {name: '{{ include "keycloak.fullname" . }}-env'}`. Add your own `secretRef`s for creds |
| `secrets.<name>.{type,labels,annotations,stringData,data}` | one Secret per entry, named `<fullname>-<name>` | `secrets.env.stringData` is where BB puts `KC_HOSTNAME*`, `KC_BOOTSTRAP_ADMIN_*`, `JAVA_*`. Maps **merge** per key, so override single vars safely |
| `extraVolumes` / `extraVolumeMounts` (tpl) | — | realm JSON, truststore, quarkus.properties, themes |
| `extraInitContainers` / `extraContainers` (tpl) | — | BB uses an init container to copy `p1-keycloak-plugin.jar` into `/opt/keycloak/providers` |
| `volumeClaimTemplates` (tpl) | per-pod PVCs | themes/providers caches; usually unnecessary |
| `extraPorts` / `serviceHeadless.extraPorts` | — | expose 7800 (JGroups) on the headless service if you use `kubernetes` stack |
| `lifecycleHooks` (tpl) | preStop etc. | `preStop: {exec: {command: [sleep, "10"]}}` gives Envoy time to drain |
| `skipInitContainers` | false | — |

### 3.3 Probes & resources

| Key | Notes |
|---|---|
| `startupProbe` / `readinessProbe` / `livenessProbe` (tpl strings) | defaults hit `/health/{started,ready,live}` on `http.internalPort` with `http.internalScheme`. Set `failureThreshold` on startup generously (60 × 5 s) — migrations |
| `resources` | JVM heap derives from the **limit**; set requests = limits in prod. Add `JAVA_OPTS_KC_HEAP=-XX:MaxRAMPercentage=70` in `secrets.env` |
| `autoscaling.{enabled,minReplicas,maxReplicas,metrics,behavior,labels}` | HPA; chart default scales down max 1 pod / 5 min so Infinispan can rebalance |

### 3.4 Exposure (normally **off** — Istio does this)

| Key | Notes |
|---|---|
| `service.{type,httpPort,httpsPort,httpNodePort,httpsNodePort,annotations,labels,extraPorts,externalTrafficPolicy,sessionAffinity,loadBalancerIP,loadBalancerSourceRanges}` | ClusterIP + Istio in BB. NodePort only for the no-Istio kind variant |
| `ingress.*` / `httpRoute.*` / `route.*` | Kubernetes Ingress, Gateway-API HTTPRoute, OpenShift Route. Leave disabled when using bb-common routes |
| `networkPolicy.{enabled,extraFrom}` | keycloakx's own NetPol; BB uses `bb-common.networkPolicies` instead |
| `serviceMonitor.*` / `extraServiceMonitor.*` / `prometheusRule.*` | Prometheus Operator objects; `serviceMonitor.port: http-internal`, `path: /metrics` |
| `test.enabled` | helm test pod |
| `extraManifests` | arbitrary extra objects (list of templated YAML) |

---

## 4. `postgresql` (Bitnami chart — most-used keys)

```yaml
postgresql:
  enabled: true                       # false = external DB; then set upstream.database.* / existingSecret
  image: {registry: docker.io, repository: bitnamilegacy/postgresql, tag: "17.6.0"}
  global:
    imagePullSecrets: []
    security: {allowInsecureImages: true}   # mandatory for any non docker.io/bitnami/* image
    postgresql:
      auth: {username: keycloak, password: keycloak, database: keycloak, postgresPassword: ""}
      # or: auth.existingSecret + auth.secretKeys.{adminPasswordKey,userPasswordKey}
  architecture: standalone            # "replication" adds read replicas (NOT automatic failover)
  primary:
    persistence: {enabled: true, size: 8Gi, storageClass: ""}
    resources: {requests: {cpu: 250m, memory: 512Mi}, limits: {cpu: "1", memory: 1Gi}}
    networkPolicy: {enabled: false}
    extendedConfiguration: |          # postgresql.conf additions
      max_connections = 300
    pgHbaConfiguration: ""            # custom pg_hba
    extraEnvVars: []                  # BB sets POSTGRESQL_* here
    extraVolumes: [] ; extraVolumeMounts: []
    podSecurityContext: {fsGroup: 1001}; containerSecurityContext: {runAsUser: 1001}
  postgresqlDataDir: /bitnami/postgresql/data   # BB overrides mountPath/dataDir for Iron Bank image
  volumePermissions: {enabled: false}
  metrics: {enabled: false}           # postgres-exporter sidecar + ServiceMonitor
  backup: {enabled: false}            # cronjob pg_dumpall to a PVC (Bitnami)
```

Service names the subchart creates: `<release>-postgresql` (primary, port 5432) and
`<release>-postgresql-hl` (headless). The secret is `<release>-postgresql` with key `password`
(and `postgres-password`).

---

## 5. Value precedence and gotchas

1. `helm … -f a.yaml -f b.yaml --set k=v`: later files override earlier, `--set` overrides files, maps merge key-by-key, **lists and strings are replaced whole**.
2. `--set-string` for anything that looks like a number/bool but must stay a string (`KC_HOSTNAME_STRICT="false"`, tags like `"17.6"`).
3. Changing anything under `upstream.secrets` changes the `checksum/secrets` pod annotation → automatic rolling restart. Changing `database.password` also rotates the DB secret but **not** the DB user's password.
4. StatefulSet immutability: `volumeClaimTemplates`, `serviceName`, `podManagementPolicy` and selector labels can't change in place — delete the StatefulSet (not the PVCs) first.
5. `upstream.image.tag` floating → unintended Keycloak upgrade on the next `helm upgrade`. Pin.
6. `fullnameOverride` is fixed by the BB chart; don't fight it — derive names from it (`keycloak-keycloak-*`).
7. The schema is strict at the top level but usually permissive inside `upstream`; a typo there (e.g. `upstream.proxy.modee`) is silently ignored. Always `helm template | grep` for the env var you expected.
