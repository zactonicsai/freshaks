#!/usr/bin/env python3
"""A minimal kubectl fake for offline integration tests, not a production utility."""
import json
import os
import pathlib
import sys

args = sys.argv[1:]
while '--context' in args:
    j = args.index('--context')
    del args[j:j+2]
if args[:2] == ['version', '--client']:
    print('Client Version: mock')
    sys.exit(0)
if args[:2] == ['config', 'current-context']:
    print('test-kind')
    sys.exit(0)
if args[:2] == ['-n', 'demo'] or (len(args) >= 2 and args[0] == '-n'):
    namespace = args[1]
    args = args[2:]
else:
    namespace = 'demo'

state = pathlib.Path(os.environ['MOCK_K8S_DIR'])
if args[:2] == ['get', 'namespace']:
    if args[2] in ['demo', 'restore-demo']:
        print('namespace/' + args[2]); sys.exit(0)
    print('NotFound', file=sys.stderr); sys.exit(1)

mapping = {
    'configmaps':'configmap', 'secrets':'secret', 'serviceaccounts':'serviceaccount',
    'roles':'role', 'rolebindings':'rolebinding',
    'persistentvolumeclaims':'persistentvolumeclaim', 'resourcequotas':'resourcequota',
    'limitranges':'limitrange', 'networkpolicies':'networkpolicy',
    'poddisruptionbudgets':'poddisruptionbudget', 'deployments':'deployment',
    'services':'service', 'horizontalpodautoscalers':'horizontalpodautoscaler',
    'ingresses':'ingress'
}

if args and args[0] == 'get':
    if args[1] == 'deployments,services':
        print('NAME\tREADY\ndeployment.apps/api\t1/1\nservice/api\t--'); sys.exit(0)
    if args[1] in mapping:
        fixture = state / f'{mapping[args[1]]}.json'
        if fixture.exists():
            print(fixture.read_text())
        else:
            print('{"apiVersion":"v1","kind":"List","items":[]}')
        sys.exit(0)
    # collision check
    if '--ignore-not-found' in args:
        existing = os.environ.get('MOCK_EXISTING', '').split(',')
        if f'{args[1]}/{args[2]}' in existing:
            print(f'{args[1]}/{args[2]}')
        sys.exit(0)
    print('NotFound',file=sys.stderr); sys.exit(1)

if args and args[0] == 'apply':
    file = args[args.index('-f') + 1]
    resource = json.loads(pathlib.Path(file).read_text())
    with open(state / 'applied.jsonl', 'a') as f:
        f.write(json.dumps({'kind': resource['kind'], 'name': resource['metadata']['name'],
                            'namespace': resource['metadata']['namespace'],
                            'dryRun': '--dry-run=server' in args}) + '\n')
    print(f"{resource['kind'].lower()}/{resource['metadata']['name']} configured")
    sys.exit(0)

print('Unknown mock command: ' + repr(args), file=sys.stderr)
sys.exit(2)
