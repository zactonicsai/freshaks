#!/usr/bin/env bash
# Kubernetes Deployment + Service backup and restore.
# Requirements: bash 3.2+, kubectl, jq, shasum (or sha256sum).
# Scope: Kubernetes API resource definitions, NOT PVC contents / databases / images.
set -Eeuo pipefail
IFS=$'\n\t'
umask 077

SCRIPT_VERSION='1.0.0'
ACTION='' NAMESPACE='' TARGET_NAMESPACE='' SERVICE='' OUTPUT='' INPUT='' CONTEXT=''
EXCLUDE_SECRETS=false DRY_RUN=false OVERWRITE=false ALLOW_EMPTY_PVCS=false
WORK='' STAGING='' SUCCESS=false
KUBECTL=(kubectl)
KINDS=(configmap secret serviceaccount role rolebinding persistentvolumeclaim resourcequota limitrange networkpolicy poddisruptionbudget deployment service horizontalpodautoscaler ingress)

default_usage() {
cat <<'HELP'
Usage:
  k8s-backup.sh backup  --namespace NAME [--service SERVICE] [--output DIRECTORY]
                         [--context CONTEXT] [--exclude-secrets]
  k8s-backup.sh restore --input DIRECTORY [--namespace TARGET_NAMESPACE]
                         [--context CONTEXT] [--dry-run] [--overwrite]
                         [--allow-empty-pvcs]

Backup modes:
  --namespace NAME           Back up ALL Deployments, Services, and related namespace
                             configuration (including Secret values by default).
  --namespace NAME --service SERVICE
                             Back up ONE Service, Deployments selected by its pod
                             selector, and discoverable dependencies.

Restore:
  --input DIRECTORY          Directory produced by backup.
  --namespace NAME           Restore into an EXISTING namespace (default: original).
  --dry-run                  Server-side validation; do not write resources.
  --overwrite                Allow updating resources already present; otherwise
                             restore refuses on any existing resource collision.
  --allow-empty-pvcs         Permit creation of new, EMPTY PVCs. Use only after
                             separately arranging required persistent volume data.

Safety:
  * Backup directory contains plaintext Secrets by default: chmod 700/600, treat
    as highly sensitive; encrypt it before moving/storing it elsewhere.
  * No volume data, PV snapshots, container images, cluster-scoped resources or
    custom resources are captured. Use Velero/CSI/DB-specific backups for those.
  * Restore never deletes or prunes existing resources, and requires an existing
    destination namespace. It does not restore PVC contents.

Examples:
  ./k8s-backup.sh backup -n payments -o ./payments-backup
  ./k8s-backup.sh backup -n payments --service api -o ./api-backup
  ./k8s-backup.sh restore --input ./api-backup --dry-run
  ./k8s-backup.sh restore --input ./api-backup --overwrite
HELP
}
log()  { printf '[INFO] %s\n' "$*" >&2; }
warn() { printf '[WARN] %s\n' "$*" >&2; }
die()  { printf '[ERROR] %s\n' "$*" >&2; exit 1; }

cleanup() {
  if [[ -n "$WORK" && -d "$WORK" ]]; then rm -rf -- "$WORK"; fi
  if [[ "$SUCCESS" != true && -n "$STAGING" && -d "$STAGING" ]]; then
    rm -rf -- "$STAGING"
  fi
}
trap cleanup EXIT
trap 'die "Interrupted or command failed at line $LINENO"' ERR

require_cmd() { command -v "$1" >/dev/null 2>&1 || die "Missing program: $1"; }
sha_file() {
  if command -v shasum >/dev/null 2>&1; then shasum -a 256 "$1" | awk '{print $1}';
  elif command -v sha256sum >/dev/null 2>&1; then sha256sum "$1" | awk '{print $1}';
  else die 'Requires shasum or sha256sum'; fi
}
parse_args() {
  (( $# >= 1 )) || { default_usage; exit 2; }
  ACTION="$1"; shift
  case "$ACTION" in backup|restore) ;; -h|--help|help) default_usage; exit 0 ;; *) die "Unknown action: $ACTION" ;; esac
  while (( $# )); do
    case "$1" in
      -n|--namespace) (( $# >= 2 )) || die "$1 needs value"; NAMESPACE="$2"; shift 2 ;;
      --service|-s) (( $# >= 2 )) || die "$1 needs value"; SERVICE="$2"; shift 2 ;;
      -o|--output) (( $# >= 2 )) || die "$1 needs value"; OUTPUT="$2"; shift 2 ;;
      -i|--input) (( $# >= 2 )) || die "$1 needs value"; INPUT="$2"; shift 2 ;;
      --context) (( $# >= 2 )) || die "$1 needs value"; CONTEXT="$2"; shift 2 ;;
      --exclude-secrets) EXCLUDE_SECRETS=true; shift ;;
      --dry-run) DRY_RUN=true; shift ;;
      --overwrite) OVERWRITE=true; shift ;;
      --allow-empty-pvcs) ALLOW_EMPTY_PVCS=true; shift ;;
      -h|--help) default_usage; exit 0 ;;
      *) die "Unknown option: $1" ;;
    esac
  done
  if [[ -n "$CONTEXT" ]]; then KUBECTL+=(--context "$CONTEXT"); fi
  if [[ "$ACTION" == backup ]]; then
    [[ -n "$NAMESPACE" ]] || die 'Backup requires --namespace'
    [[ -z "$INPUT" && "$DRY_RUN" == false && "$OVERWRITE" == false && "$ALLOW_EMPTY_PVCS" == false ]] || die 'Restore-only option on backup'
    [[ "$NAMESPACE" =~ ^[a-z0-9]([-a-z0-9]*[a-z0-9])?$ ]] || die 'Invalid namespace name'
    if [[ -n "$SERVICE" ]]; then
      [[ "$SERVICE" =~ ^[a-z0-9]([-a-z0-9.]*[a-z0-9])?$ ]] || die 'Invalid Service name'
    fi
  else
    [[ -n "$INPUT" ]] || die 'Restore requires --input'
    [[ -z "$SERVICE" && -z "$OUTPUT" && "$EXCLUDE_SECRETS" == false ]] || die 'Backup-only option on restore'
    if [[ -n "$NAMESPACE" ]]; then
      [[ "$NAMESPACE" =~ ^[a-z0-9]([-a-z0-9]*[a-z0-9])?$ ]] || die 'Invalid namespace name'
    fi
  fi
}
check_tools_and_cluster() {
  require_cmd kubectl; require_cmd jq
  command -v shasum >/dev/null 2>&1 || require_cmd sha256sum
  "${KUBECTL[@]}" version --client >/dev/null
  local active
  active=$("${KUBECTL[@]}" config current-context 2>/dev/null || true)
  [[ -n "$CONTEXT" ]] || CONTEXT="$active"
  log "Kubernetes context: ${CONTEXT:-unknown}"
  if [[ -n "$NAMESPACE" ]]; then
    "${KUBECTL[@]}" get namespace "$NAMESPACE" -o name >/dev/null || die "Namespace '$NAMESPACE' must already exist"
  fi
}

# Cache every resource list once so discovery sees a reasonably consistent view.
# Some names use non-trivial plurals; always use explicit Kubernetes resource types.
resource_plural() {
  case "$1" in
    ingress) printf 'ingresses' ;; networkpolicy) printf 'networkpolicies' ;;
    poddisruptionbudget) printf 'poddisruptionbudgets' ;;
    persistentvolumeclaim) printf 'persistentvolumeclaims' ;;
    resourcequota) printf 'resourcequotas' ;;
    horizontalpodautoscaler) printf 'horizontalpodautoscalers' ;;
    *) printf '%ss' "$1" ;;
  esac
}
load_kind() {
  local kind="$1" file plural
  file="$WORK/get-${kind}.json"
  [[ -f "$file" ]] && return 0
  plural=$(resource_plural "$kind")
  "${KUBECTL[@]}" -n "$NAMESPACE" get "$plural" -o json > "$file" || die "Cannot list $plural in '$NAMESPACE' (check permissions/API support)"
}
resource_exists_in_cache() {
  local kind="$1" name="$2"
  load_kind "$kind"
  jq -e --arg name "$name" 'any(.items[]; .metadata.name == $name)' "$WORK/get-${kind}.json" >/dev/null
}
order_for_kind() {
  case "$1" in
    configmap|secret|serviceaccount|role|rolebinding|resourcequota|limitrange) echo 10 ;;
    persistentvolumeclaim) echo 20 ;;
    networkpolicy|poddisruptionbudget) echo 30 ;;
    deployment) echo 40 ;;
    service) echo 50 ;;
    horizontalpodautoscaler|ingress) echo 60 ;;
    *) die "Unsupported kind $1" ;;
  esac
}
# Removes server-assigned, cluster-specific and otherwise unsafe metadata.
# Keeps meaningful application labels, annotations and workload specs.
sanitize_one() {
  local kind="$1" name="$2" destination="$3"
  jq -e --arg name "$name" --arg kind "$kind" '
    .items[] | select(.metadata.name == $name)
    | del(.status, .metadata.uid, .metadata.resourceVersion,
          .metadata.creationTimestamp, .metadata.generation,
          .metadata.managedFields, .metadata.selfLink, .metadata.finalizers,
          .metadata.ownerReferences, .metadata.deletionTimestamp,
          .metadata.deletionGracePeriodSeconds,
          .metadata.annotations."kubectl.kubernetes.io/last-applied-configuration",
          .metadata.annotations."deployment.kubernetes.io/revision")
    | if $kind == "service" then
        del(.spec.clusterIPs, .spec.healthCheckNodePort, .spec.ipFamilies,
            .spec.ipFamilyPolicy, .spec.ports[]?.nodePort)
        | if .spec.clusterIP == "None" then . else del(.spec.clusterIP) end
      elif $kind == "serviceaccount" then del(.secrets)
      elif $kind == "persistentvolumeclaim" then
        del(.spec.volumeName,
            .metadata.annotations."pv.kubernetes.io/bind-completed",
            .metadata.annotations."pv.kubernetes.io/bound-by-controller",
            .metadata.annotations."volume.kubernetes.io/selected-node")
      else . end
  ' "$WORK/get-${kind}.json" > "$destination"
}
write_resource() {
  local kind="$1" name="$2" path rel digest order
  [[ "$name" =~ ^[a-z0-9]([-a-z0-9.]*[a-z0-9])?$ ]] || die "Unexpected unsafe Kubernetes resource name '$name'"
  [[ "$kind" != secret || "$EXCLUDE_SECRETS" == false ]] || return 0
  [[ "$kind" != configmap || "$name" != kube-root-ca.crt ]] || return 0
  if [[ "$kind" == secret ]]; then
    local stype
    stype=$(jq -r --arg n "$name" '.items[] | select(.metadata.name==$n) | .type // ""' "$WORK/get-secret.json")
    [[ "$stype" != kubernetes.io/service-account-token ]] || return 0
  fi
  order=$(order_for_kind "$kind")
  rel="resources/${order}-${kind}/${name}.json"
  path="$STAGING/$rel"
  [[ -e "$path" ]] && return 0
  mkdir -p -- "$(dirname "$path")"
  sanitize_one "$kind" "$name" "$path" || die "Cannot serialize $kind/$name"
  digest=$(sha_file "$path")
  printf '%s\t%s\t%s\t%s\t%s\n' "$order" "$kind" "$name" "$rel" "$digest" >> "$STAGING/index.tsv"
  log "Saved $kind/$name"
}
add_if_present() {
  local kind="$1" name="$2"
  [[ -n "$name" && "$name" != null ]] || return 0
  if resource_exists_in_cache "$kind" "$name"; then
    write_resource "$kind" "$name"
  else
    warn "Referenced dependency $kind/$name not found (may be optional/external)"
  fi
}
backup_whole_namespace() {
  local kind name
  for kind in "${KINDS[@]}"; do
    load_kind "$kind"
    while IFS= read -r name; do
      [[ -n "$name" ]] && write_resource "$kind" "$name"
    done < <(jq -r '.items[].metadata.name' "$WORK/get-${kind}.json")
  done
}
# Select Deployment pod templates matched by the requested Service selector,
# not by assuming Service and Deployment have the same name.
find_service_deployments() {
  local selector_json="$1"
  jq -r --argjson selector "$selector_json" '
    [.items[]
     | select(.spec.template.metadata.labels as $labels
         | ($selector | to_entries | all(.[]; $labels[.key] == .value)))
     | .metadata.name] | .[]
  ' "$WORK/get-deployment.json"
}
# Find ConfigMaps, Secrets, image pull Secrets, PVCs and ServiceAccount references
# in containers, initContainers, ephemeralContainers, volumes and projections.
extract_pod_references() {
  local name="$1" depfile="$WORK/get-deployment.json"
  jq -r --arg name "$name" '
    .items[] | select(.metadata.name == $name) | .spec.template.spec as $p |
    (
      ($p.serviceAccountName // "default" | "serviceaccount\t" + .),
      ($p.imagePullSecrets[]?.name | "secret\t" + .),
      ($p.volumes[]?.configMap.name | "configmap\t" + .),
      ($p.volumes[]?.secret.secretName | "secret\t" + .),
      ($p.volumes[]?.persistentVolumeClaim.claimName | "persistentvolumeclaim\t" + .),
      ($p.volumes[]?.projected.sources[]?.configMap.name | "configmap\t" + .),
      ($p.volumes[]?.projected.sources[]?.secret.name | "secret\t" + .),
      ([$p.containers[]?, $p.initContainers[]?, $p.ephemeralContainers[]?][]
         | (.env[]?.valueFrom.configMapKeyRef.name | "configmap\t" + .),
           (.env[]?.valueFrom.secretKeyRef.name | "secret\t" + .),
           (.envFrom[]?.configMapRef.name | "configmap\t" + .),
           (.envFrom[]?.secretRef.name | "secret\t" + .)
      )
    )
  ' "$depfile" | sort -u
}
# Include RoleBindings that refer to a selected ServiceAccount, plus any local
# Roles they reference. ClusterRoles live outside the namespace: never export.
backup_serviceaccount_rbac() {
  local account="$1" rb role image_secret
  # A ServiceAccount can specify imagePullSecrets even when the Pod does not.
  load_kind serviceaccount
  while IFS= read -r image_secret; do
    [[ -z "$image_secret" ]] || add_if_present secret "$image_secret"
  done < <(jq -r --arg sa "$account" '.items[] | select(.metadata.name==$sa)
      | .imagePullSecrets[]?.name' "$WORK/get-serviceaccount.json")
  load_kind rolebinding
  while IFS= read -r rb; do
    [[ -n "$rb" ]] || continue
    write_resource rolebinding "$rb"
    role=$(jq -r --arg n "$rb" '.items[] | select(.metadata.name==$n)
      | if .roleRef.kind=="Role" then .roleRef.name else empty end' "$WORK/get-rolebinding.json")
    [[ -n "$role" ]] && add_if_present role "$role"
  done < <(jq -r --arg sa "$account" --arg ns "$NAMESPACE" '
    .items[] | select(any(.subjects[]?;
      .kind=="ServiceAccount" and .name==$sa and ((.namespace // $ns)==$ns)))
    | .metadata.name' "$WORK/get-rolebinding.json")
}
backup_ingress_hpa_pdb_netpol() {
  local dep="$1" svc="$2" name
  load_kind horizontalpodautoscaler
  while IFS= read -r name; do
    [[ -z "$name" ]] || write_resource horizontalpodautoscaler "$name"
  done < <(jq -r --arg d "$dep" '.items[] | select(.spec.scaleTargetRef.kind=="Deployment"
      and .spec.scaleTargetRef.name==$d) | .metadata.name' "$WORK/get-horizontalpodautoscaler.json")

  # MatchLabels-based selectors are common; complex matchExpressions may need
  # manual review. An empty PDB selector is deliberately ignored here.
  load_kind poddisruptionbudget; load_kind networkpolicy
  local labels
  labels=$(jq -c --arg d "$dep" '.items[] | select(.metadata.name==$d)
      | .spec.template.metadata.labels // {}' "$WORK/get-deployment.json")
  for name in poddisruptionbudget networkpolicy; do
    local target="$name"
    while IFS= read -r selected; do
      [[ -z "$selected" ]] || write_resource "$target" "$selected"
    done < <(jq -r --argjson labels "$labels" '
      .items[] | (.spec.selector.matchLabels // .spec.podSelector.matchLabels // {}) as $sel
      | select(($sel | length) > 0 and
          ($sel | to_entries | all(.[]; $labels[.key] == .value)))
      | .metadata.name' "$WORK/get-${target}.json")
  done
}
backup_one_service() {
  local svc="$SERVICE" selector_json dep kind name sa
  load_kind service; load_kind deployment
  resource_exists_in_cache service "$svc" || die "Service '$svc' does not exist in '$NAMESPACE'"
  selector_json=$(jq -c --arg s "$svc" '.items[] | select(.metadata.name==$s) | .spec.selector // {}' "$WORK/get-service.json")
  [[ $(jq -r 'length' <<< "$selector_json") -gt 0 ]] || die "Service '$svc' has no selector; cannot discover a Deployment"
  write_resource service "$svc"
  local count=0
  while IFS= read -r dep; do
    [[ -n "$dep" ]] || continue
    count=$((count + 1))
    write_resource deployment "$dep"
    extract_pod_references "$dep" > "$WORK/refs-${dep}.tsv"
    while IFS=$'\t' read -r kind name; do
      [[ -z "$kind" ]] || add_if_present "$kind" "$name"
      if [[ "$kind" == serviceaccount && -n "$name" ]]; then
        backup_serviceaccount_rbac "$name"
      fi
    done < "$WORK/refs-${dep}.tsv"
    backup_ingress_hpa_pdb_netpol "$dep" "$svc"
  done < <(find_service_deployments "$selector_json")
  (( count > 0 )) || die "No Deployment's pod labels match Service '$svc'; Service-only backup would be incomplete"

  load_kind ingress
  while IFS= read -r name; do
    [[ -z "$name" ]] || write_resource ingress "$name"
  done < <(jq -r --arg s "$svc" '.items[]
    | select((.spec.defaultBackend.service.name // "") == $s
       or any(.spec.rules[]?.http.paths[]?; .backend.service.name == $s))
    | .metadata.name' "$WORK/get-ingress.json")
}
backup_action() {
  [[ -n "$OUTPUT" ]] || OUTPUT="./k8s-${NAMESPACE}${SERVICE:+-${SERVICE}}-$(date -u +%Y%m%dT%H%M%SZ)"
  [[ ! -e "$OUTPUT" ]] || die "Output exists (will not overwrite): $OUTPUT"
  local parent
  parent=$(dirname "$OUTPUT")
  [[ -d "$parent" ]] || die "Output parent directory does not exist: $parent"
  STAGING=$(mktemp -d "${OUTPUT}.partial.XXXXXX")
  chmod 700 "$STAGING"
  : > "$STAGING/index.tsv"
  WORK=$(mktemp -d)
  if [[ -n "$SERVICE" ]]; then backup_one_service; else backup_whole_namespace; fi
  [[ -s "$STAGING/index.tsv" ]] || die 'Nothing found to back up'
  LC_ALL=C sort -t $'\t' -k1,1n -k2,2 -k3,3 "$STAGING/index.tsv" > "$STAGING/index.sorted"
  mv "$STAGING/index.sorted" "$STAGING/index.tsv"
  jq -n --arg v "$SCRIPT_VERSION" --arg ns "$NAMESPACE" --arg ctx "$CONTEXT" \
    --arg svc "$SERVICE" --arg timestamp "$(date -u +%Y-%m-%dT%H:%M:%SZ)" \
    --argjson noSecrets "$EXCLUDE_SECRETS" \
    '{formatVersion:1, toolVersion:$v, namespace:$ns, sourceContext:$ctx,
      scope:(if $svc=="" then "namespace" else "service" end), service:$svc,
      createdUtc:$timestamp, secretsExcluded:$noSecrets,
      warning:"Does NOT contain PV data, database backups, container images, cluster resources or custom resources"}' > "$STAGING/metadata.json"
  chmod 600 "$STAGING/index.tsv" "$STAGING/metadata.json"
  mv "$STAGING" "$OUTPUT"
  STAGING=''
  SUCCESS=true
  log "Backup complete: $OUTPUT"
  log "Resources saved: $(wc -l < "$OUTPUT/index.tsv" | tr -d ' ')"
  [[ "$EXCLUDE_SECRETS" == true ]] || warn 'BACKUP INCLUDES PLAINTEXT SECRET VALUES. Encrypt archive/storage and restrict access.'
  if grep -q $'\tpersistentvolumeclaim\t' "$OUTPUT/index.tsv"; then
    warn 'PVC definitions captured, but PVC FILE/DATABASE DATA was NOT backed up.'
  fi
}
verify_backup() {
  [[ -d "$INPUT" && -f "$INPUT/index.tsv" && -f "$INPUT/metadata.json" ]] || die 'Invalid backup: metadata.json or index.tsv not found'
  jq -e '.formatVersion == 1 and (.namespace | type == "string")' "$INPUT/metadata.json" >/dev/null || die 'Unsupported/invalid metadata.json'
  local order kind name relative expected actual count=0
  while IFS=$'\t' read -r order kind name relative expected; do
    [[ "$order" =~ ^[0-9]+$ && "$kind" =~ ^[a-z]+$ && "$name" =~ ^[a-z0-9.-]+$ ]] || die 'Invalid index fields'
    [[ "$relative" == "resources/${order}-${kind}/${name}.json" ]] || die 'Unsafe or malformed resource path in index'
    [[ "$expected" =~ ^[a-f0-9]{64}$ ]] || die "Invalid checksum for $relative"
    [[ -f "$INPUT/$relative" && ! -L "$INPUT/$relative" ]] || die "Missing or symlinked: $relative"
    actual=$(sha_file "$INPUT/$relative")
    [[ "$actual" == "$expected" ]] || die "Checksum mismatch: $relative"
    jq -e --arg kind "$kind" --arg name "$name" \
      '.metadata.name == $name and (.kind | ascii_downcase) == $kind' "$INPUT/$relative" >/dev/null || die "Resource name/kind mismatch: $relative"
    count=$((count + 1))
  done < "$INPUT/index.tsv"
  (( count > 0 )) || die 'Empty backup index'
  log "Verified $count resources and SHA-256 checksums"
}
prepare_restore_files() {
  local order kind name relative checksum target="$TARGET_NAMESPACE" path staged original_ns
  original_ns=$(jq -r '.namespace' "$INPUT/metadata.json")
  mkdir -p "$WORK/rendered"
  while IFS=$'\t' read -r order kind name relative checksum; do
    path="$INPUT/$relative"
    staged="$WORK/rendered/${order}-${kind}-${name}.json"
    jq --arg ns "$target" --arg original "$original_ns" '
      .metadata.namespace = $ns
      | if .kind == "RoleBinding" then
          .subjects = [(.subjects // [])[] |
            if .kind == "ServiceAccount" and ((.namespace // $original) == $original)
            then .namespace = $ns else . end]
        else . end
    ' "$path" > "$staged"
    printf '%s\t%s\t%s\t%s\n' "$order" "$kind" "$name" "$staged" >> "$WORK/rendered-index.tsv"
  done < "$INPUT/index.tsv"
}
restore_action() {
  verify_backup
  TARGET_NAMESPACE="$NAMESPACE"
  [[ -n "$TARGET_NAMESPACE" ]] || TARGET_NAMESPACE=$(jq -r '.namespace' "$INPUT/metadata.json")
  [[ "$TARGET_NAMESPACE" =~ ^[a-z0-9]([-a-z0-9]*[a-z0-9])?$ ]] || die 'Invalid destination namespace'
  "${KUBECTL[@]}" get namespace "$TARGET_NAMESPACE" -o name >/dev/null || die "Target namespace '$TARGET_NAMESPACE' must already exist"
  WORK=$(mktemp -d)
  prepare_restore_files
  local order kind name path collisions=0
  log "Target namespace: $TARGET_NAMESPACE"
  # Do not silently create empty storage when a PVC's data is missing.
  # Existing bound PVCs are never deleted or recreated by this tool.
  if [[ "$DRY_RUN" == false && "$ALLOW_EMPTY_PVCS" == false ]]; then
    while IFS=$'\t' read -r order kind name path; do
      if [[ "$kind" == persistentvolumeclaim ]] && \
         [[ -z "$("${KUBECTL[@]}" -n "$TARGET_NAMESPACE" get persistentvolumeclaim "$name" --ignore-not-found -o name)" ]]; then
        die "PVC '$name' is absent in target namespace. Restoring its manifest would create EMPTY storage. Restore data separately then rerun, or explicitly use --allow-empty-pvcs. No resources were changed."
      fi
    done < "$WORK/rendered-index.tsv"
  fi
  if [[ "$DRY_RUN" == false && "$OVERWRITE" == false ]]; then
    while IFS=$'\t' read -r order kind name path; do
      if [[ -n "$("${KUBECTL[@]}" -n "$TARGET_NAMESPACE" get "$kind" "$name" --ignore-not-found -o name)" ]]; then
        warn "Already exists: $kind/$name (use --overwrite to update existing objects)"
        collisions=$((collisions + 1))
      fi
    done < "$WORK/rendered-index.tsv"
    (( collisions == 0 )) || die "Found $collisions existing objects; no resources were changed"
  fi
  # First validate all files server-side before any write.
  # Some admission webhooks require prerequisites already created; in that case
  # per-resource real apply will report the actionable failure.
  if [[ "$DRY_RUN" == true ]]; then
    while IFS=$'\t' read -r order kind name path; do
      log "Validate $kind/$name"
      "${KUBECTL[@]}" -n "$TARGET_NAMESPACE" apply --dry-run=server -f "$path"
    done < "$WORK/rendered-index.tsv"
    log 'Dry run succeeded. No cluster resources were changed.'
    return 0
  fi
  while IFS=$'\t' read -r order kind name path; do
    log "Apply $kind/$name"
    "${KUBECTL[@]}" -n "$TARGET_NAMESPACE" apply -f "$path"
  done < "$WORK/rendered-index.tsv"
  log 'Restore completed. Inspect Deployments/Pods/Services for readiness.'
  "${KUBECTL[@]}" -n "$TARGET_NAMESPACE" get deployments,services
  warn 'Persistent volume data, images and external dependencies require separate recovery.'
}
main() {
  parse_args "$@"
  check_tools_and_cluster
  case "$ACTION" in backup) backup_action ;; restore) restore_action ;; esac
}
main "$@"
