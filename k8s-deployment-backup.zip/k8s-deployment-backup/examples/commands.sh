#!/usr/bin/env bash
# Example commands ONLY. Modify namespace/context/paths before running.
# Run individual lines intentionally, not the whole file automatically.

# Check context before accessing the API:
# kubectl config current-context
# kubectl get ns demo

# Full namespace configuration backup:
# mkdir -p ./backups
# ./k8s-backup.sh backup -n demo -o ./backups/demo-20261112

# One Service and the Deployment(s) behind it:
# ./k8s-backup.sh backup -n demo --service web -o ./backups/demo-web

# Validate without changing cluster:
# ./k8s-backup.sh restore --input ./backups/demo-web -n demo --dry-run

# When destination objects already exist, intentionally update (no deletions):
# ./k8s-backup.sh restore --input ./backups/demo-web -n demo --overwrite

# If missing PVCs should be created EMPTY (NOT data recovery):
# ./k8s-backup.sh restore --input ./backups/demo-web -n demo --allow-empty-pvcs
