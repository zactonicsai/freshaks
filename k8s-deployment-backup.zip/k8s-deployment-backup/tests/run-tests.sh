#!/usr/bin/env bash
set -Eeuo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
TMP=$(mktemp -d)
trap 'rm -rf "$TMP"' EXIT
mkdir -p "$TMP/bin" "$TMP/data"
cp "$ROOT/tests/mock_kubectl.py" "$TMP/bin/kubectl"
chmod +x "$TMP/bin/kubectl"
# Use the lightweight system interpreter when available; on macOS the
# normal Python from PATH is used instead.
if [[ -x /usr/bin/python3 ]]; then ln -s /usr/bin/python3 "$TMP/bin/python3"; fi
export PATH="$TMP/bin:$PATH" MOCK_K8S_DIR="$TMP/data"
python3 - <<'PY'
import os, json, pathlib
p = pathlib.Path(os.environ['MOCK_K8S_DIR'])
def put(kind, items):
    (p/(kind+'.json')).write_text(json.dumps({'apiVersion':'v1','kind':'List','items':items}))
def obj(kind, name, spec=None, **other):
    return {'apiVersion':('apps/v1' if kind=='Deployment' else 'v1'), 'kind':kind,
            'metadata':{'name':name,'namespace':'demo','uid':'random-uid',
                        'resourceVersion':'99','managedFields':[{}]},
            'spec':spec or {},'status':{'phase':'ignore'}, **other}
put('deployment', [obj('Deployment','api-v2',{'template':{'metadata':{'labels':{'app':'api','tier':'backend'}},
    'spec':{'serviceAccountName':'api-sa','imagePullSecrets':[{'name':'registry'}],
    'containers':[{'name':'api','image':'example/api:2','envFrom':[{'configMapRef':{'name':'settings'}},
     {'secretRef':{'name':'api-credentials'}}]}],
    'volumes':[{'name':'appdata','persistentVolumeClaim':{'claimName':'data-pvc'}}]}}})])
put('service', [obj('Service','api',{'selector':{'app':'api'},'clusterIP':'10.43.0.10',
        'clusterIPs':['10.43.0.10'],'ports':[{'port':80,'nodePort':30001}], 'type':'NodePort'}),
     obj('Service','unrelated',{'selector':{'app':'unrelated'},'ports':[{'port':81}]})])
put('configmap', [obj('ConfigMap','settings',None,data={'APP_ENV':'prod'}),
     obj('ConfigMap','unrelated-settings',None,data={'X':'Y'})])
put('secret', [obj('Secret','api-credentials',None,type='Opaque',data={'password':'dGVzdA=='}),
     obj('Secret','registry',None,type='kubernetes.io/dockerconfigjson',data={'.dockerconfigjson':'e30='}),
     obj('Secret','api-sa-token',None,type='kubernetes.io/service-account-token',data={'token':'dA=='})])
put('serviceaccount',[obj('ServiceAccount','api-sa'), obj('ServiceAccount','default')])
put('role',[obj('Role','api-reader')])
put('rolebinding',[obj('RoleBinding','api-reader-bind',{'notInRealRB':'ok'},
     subjects=[{'kind':'ServiceAccount','name':'api-sa','namespace':'demo'}],roleRef={'kind':'Role','name':'api-reader','apiGroup':'rbac.authorization.k8s.io'})])
put('persistentvolumeclaim',[obj('PersistentVolumeClaim','data-pvc',
 {'storageClassName':'standard','volumeName':'pvc-uuid','resources':{'requests':{'storage':'1Gi'}},
  'accessModes':['ReadWriteOnce']})])
put('horizontalpodautoscaler',[obj('HorizontalPodAutoscaler','api-scaler',{'scaleTargetRef':{'kind':'Deployment','name':'api-v2'},'maxReplicas':3})])
put('ingress',[obj('Ingress','api-ingress',{'rules':[{'http':{'paths':[{'backend':{'service':{'name':'api','port':{'number':80}}}}]}}]})])
put('poddisruptionbudget',[])
put('networkpolicy',[])
PY

bash -n "$ROOT/k8s-backup.sh"
"$ROOT/k8s-backup.sh" backup -n demo --service api -o "$TMP/service-backup"
[[ -f "$TMP/service-backup/resources/40-deployment/api-v2.json" ]]
[[ -f "$TMP/service-backup/resources/50-service/api.json" ]]
[[ -f "$TMP/service-backup/resources/10-secret/api-credentials.json" ]]
[[ -f "$TMP/service-backup/resources/20-persistentvolumeclaim/data-pvc.json" ]]
[[ ! -f "$TMP/service-backup/resources/10-configmap/unrelated-settings.json" ]]
[[ ! -f "$TMP/service-backup/resources/10-secret/api-sa-token.json" ]]
jq -e '.spec.clusterIP == null and .spec.ports[0].nodePort == null and .metadata.uid == null' \
 "$TMP/service-backup/resources/50-service/api.json" >/dev/null
jq -e '.spec.volumeName == null' "$TMP/service-backup/resources/20-persistentvolumeclaim/data-pvc.json" >/dev/null
"$ROOT/k8s-backup.sh" restore --input "$TMP/service-backup" -n restore-demo --dry-run
jq -e -s 'length > 6 and all(.[]; .namespace=="restore-demo" and .dryRun==true)' "$TMP/data/applied.jsonl" >/dev/null
rm -f "$TMP/data/applied.jsonl"
# A missing PVC needs an explicit flag before any real apply happens.
if "$ROOT/k8s-backup.sh" restore --input "$TMP/service-backup" -n restore-demo > /dev/null 2>&1; then
  echo 'ERROR: missing PVC data guard failed' >&2; exit 1
fi
[[ ! -e "$TMP/data/applied.jsonl" ]]
"$ROOT/k8s-backup.sh" restore --input "$TMP/service-backup" -n restore-demo --allow-empty-pvcs
jq -e -s 'length > 6 and all(.[]; .namespace=="restore-demo" and .dryRun==false)' "$TMP/data/applied.jsonl" >/dev/null
if MOCK_EXISTING='service/api' "$ROOT/k8s-backup.sh" restore --input "$TMP/service-backup" -n restore-demo --allow-empty-pvcs > /dev/null 2>&1; then
  echo 'ERROR: existing-resource collision guard failed' >&2; exit 1
fi
# Verify checksum tampering is refused before anything is applied.
cp -R "$TMP/service-backup" "$TMP/tampered-backup"
printf ' ' >> "$TMP/tampered-backup/resources/50-service/api.json"
if "$ROOT/k8s-backup.sh" restore --input "$TMP/tampered-backup" -n restore-demo --dry-run >/dev/null 2>&1; then
  echo 'ERROR: checksum validation failed' >&2; exit 1
fi
"$ROOT/k8s-backup.sh" backup -n demo -o "$TMP/namespace-backup" >/dev/null
[[ -f "$TMP/namespace-backup/resources/50-service/unrelated.json" ]]
[[ -f "$TMP/namespace-backup/resources/10-configmap/unrelated-settings.json" ]]
"$ROOT/k8s-backup.sh" backup -n demo --service api -o "$TMP/no-secrets" --exclude-secrets >/dev/null
[[ ! -d "$TMP/no-secrets/resources/10-secret" ]]
echo 'ALL OFFLINE TESTS PASSED'
